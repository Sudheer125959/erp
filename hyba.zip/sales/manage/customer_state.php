<?php
/**********************************************************************
Copyright (C) , LLC.
Released under the terms of the GNU General Public License, GPL,
as published by the Free Software Foundation, either version 3
of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the License here <http://www.gnu.org/licenses/gpl-3.0.html>.
 ***********************************************************************/
$page_security = 'SA_CUSTOMER';
$path_to_root = "../..";
include($path_to_root . "/includes/session.inc");
page(_($help_context = "Customer State"));
include($path_to_root . "/includes/ui.inc");
include($path_to_root . "/sales/includes/db/customer_state_db.inc");

simple_page_mode(true);
//-----------------------------------------------------------------------------------

function can_process($update=false)
{

    if (strlen($_POST['state_code']) == 0)
    {
        display_error(_("State Code cannot be empty."));
        set_focus('state_code');
        return false;
    }
    if (!$update&&key_in_foreign_table($_POST['state_code'],'customer_state','state_code'))
    {
        display_error(_("This State Code have been already added."));
        set_focus('state_code');
        return false;
    }

    if (strlen($_POST['name']) == 0)
    {
        display_error(_("State cannot be empty."));
        set_focus('name');
        return false;
    }
    if (key_in_foreign_table($_POST['name'],'customer_state','name'))
    {
        display_error(_("This State have been already added."));
        set_focus('name');
        return false;
    }

    return true;
}

//-----------------------------------------------------------------------------------

if ($Mode=='ADD_ITEM' && can_process())
{
    add_state($_POST['state_code'], $_POST['name']);
    display_notification(_('New credit state has been added'));
    $Mode = 'RESET';
}

//-----------------------------------------------------------------------------------

if ($Mode=='UPDATE_ITEM' && can_process(true))
{
    update_state($selected_id, $_POST['name']);
    display_notification(_('Selected credit status has been updated'));
    $Mode = 'RESET';
}

//-----------------------------------------------------------------------------------

function can_delete($selected_id)
{
    if (key_in_foreign_table($selected_id,'customer_district','state_code'))
    {
        display_error(_("This State cannot be deleted."));
        set_focus('state_code');
        return false;
    }

    return true;
}

//-----------------------------------------------------------------------------------

if ($Mode == 'Delete')
{
    if (can_delete($selected_id))
    {
        delete_state($selected_id);
        display_notification(_('Selected state has been deleted'));
    }
    $Mode = 'RESET';
}

if ($Mode == 'RESET')
{
    $selected_id = -1;
    $sav = get_post('show_inactive');
    unset($_POST);
    $_POST['show_inactive'] = $sav;
}
//-----------------------------------------------------------------------------------

$result = get_all_states(check_value('show_inactive'));

start_form();
start_table(TABLESTYLE, "width=40%");
$th = array(_("state_code"),_("name"),'','');
inactive_control_column($th);
table_header($th);

$k = 0;
while ($myrow = db_fetch($result))
{
    alt_table_row_color($k);
    label_cell($myrow["state_code"]);
    label_cell($myrow["name"]);
    inactive_control_cell($myrow["state_code"], $myrow["inactive"], 'customer_state', 'state_code');
    edit_button_cell("Edit".$myrow['state_code'], _("Edit"));
    delete_button_cell("Delete".$myrow['state_code'], _("Delete"));
    end_row();
}

inactive_control_row($th);
end_table();
echo '<br>';

//-----------------------------------------------------------------------------------

start_table(TABLESTYLE2);

if ($selected_id != -1)
{
    if ($Mode == 'Edit')
    {   //editing an existing status code
        $myrow = get_state_status($selected_id);
        $_POST['state_code']  = $myrow["state_code"];
        $_POST['name']  = $myrow["name"];
    }
    label_row(_("Stat Code:"),$myrow["state_code"]);
    hidden('state_code', $myrow["state_code"]);
    hidden('selected_id', $myrow["state_code"]);
}
else
    text_row(_("State Code:"), 'state_code', null, 30, 30);
text_row(_("Name"), 'name', null, 42, 40);

end_table(1);
submit_add_or_update_center($selected_id == -1, '', 'both');
end_form();

//------------------------------------------------------------------------------------

end_page();
?>