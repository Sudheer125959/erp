<?php
$page_security = 'SA_TAXREP';
$path_to_root = "..";
include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include_once($path_to_root . "/gl/includes/gl_db.inc");
print_tax_report();
function getTaxTransactions($from, $to)
{
    $fromdate = date2sql($from);
    $todate = date2sql($to);

    $sql = "SELECT tt.name as taxname, taxrec.*, taxrec.amount*ex_rate AS amount,
	            taxrec.net_amount*ex_rate AS net_amount,
				IF(taxrec.trans_type=".ST_BANKPAYMENT." OR taxrec.trans_type=".ST_BANKDEPOSIT.", 
					IF(gl.person_type_id<>".PT_MISC.", gl.memo_, gl.person_id), 
					IF(ISNULL(supp.supp_name), debt.name, supp.supp_name)) as name,
				branch.br_name
		FROM " . TB_PREF . "trans_tax_details taxrec
		LEFT JOIN " . TB_PREF . "tax_types tt
			ON taxrec.tax_type_id=tt.id
		LEFT JOIN " . TB_PREF . "gl_trans gl 
			ON taxrec.trans_type=gl.type AND taxrec.trans_no=gl.type_no AND gl.amount<>0 AND
			(tt.purchasing_gl_code=gl.account OR tt.sales_gl_code=gl.account)
		LEFT JOIN " . TB_PREF . "supp_trans strans
			ON taxrec.trans_no=strans.trans_no AND taxrec.trans_type=strans.type
		LEFT JOIN " . TB_PREF . "suppliers as supp ON strans.supplier_id=supp.supplier_id
		LEFT JOIN " . TB_PREF . "debtor_trans dtrans
			ON taxrec.trans_no=dtrans.trans_no AND taxrec.trans_type=dtrans.type
		LEFT JOIN " . TB_PREF . "debtors_master as debt ON dtrans.debtor_no=debt.debtor_no
		LEFT JOIN " . TB_PREF . "cust_branch as branch ON dtrans.branch_code=branch.branch_code
		WHERE (taxrec.amount <> 0 OR taxrec.net_amount <> 0)
			AND !ISNULL(taxrec.reg_type)
			AND taxrec.tran_date >= '$fromdate'
			AND taxrec.tran_date <= '$todate'
		ORDER BY taxrec.trans_type, taxrec.tran_date, taxrec.trans_no, taxrec.ex_rate";

    return db_query($sql, "No transactions were returned");
}
function getTaxTypes()
{
    $sql = "SELECT * FROM " . TB_PREF . "tax_types ORDER BY id";
    return db_query($sql, "No transactions were returned");
}
function getTaxInfo($id)
{
    $sql = "SELECT * FROM " . TB_PREF . "tax_types WHERE id=$id";
    $result = db_query($sql, "No transactions were returned");
    return db_fetch($result);
}
function get_Total_no_of_records($from, $to)
{
    $fromdate = date2sql($from);
    $todate = date2sql($to);
    $sql = "SELECT count(DISTINCT(trans_no)) FROM `".TB_PREF."trans_tax_details` 
            WHERE trans_type = ".ST_SALESINVOICE." AND `tran_date` >='$fromdate' AND tran_date <= '$todate'";
    $result = db_query($sql,"No transactions were returned");
    if(db_num_rows($result))
        return db_fetch($result)[0];
    else
        return 0;
}
function get_Total_no_of_recipients($from, $to)
{
    $fromdate = date2sql($from);
    $todate = date2sql($to);
    $sql = "SELECT count(DISTINCT(dt.debtor_no)) 
            FROM `".TB_PREF."trans_tax_details` as ttd 
            LEFT JOIN `".TB_PREF."debtor_trans` as dt ON dt.trans_no = ttd.trans_no AND dt.type = ".ST_SALESINVOICE."
            LEFT JOIN `".TB_PREF."debtors_master` as dm ON  dt.debtor_no = dm.debtor_no 
            WHERE ttd.trans_type = ".ST_SALESINVOICE."
            AND ttd.`tran_date` BETWEEN  '$fromdate' AND '$todate'";
    $result = db_query($sql,"No transactions were returned");
    if(db_num_rows($result))
        return db_fetch($result)[0];
    else
        return 0;
}

function get_total_transactions($from, $to)
{
    $fromdate = date2sql($from);
    $todate = date2sql($to);
    $sql = "SELECT SUM(dt.ov_amount+dt.ov_gst+dt.ov_freight+dt.ov_freight_tax) as total , SUM(dt.ov_amount) as basic
           FROM ".TB_PREF."debtor_trans as dt 
            WHERE dt.type = ".ST_SALESINVOICE."
            AND dt.tran_date >='$fromdate' AND dt.tran_date <='$todate'";
    $result = db_query($sql,"No transactions were returned");
    return db_fetch($result);
}

function get_each_transactions($from, $to)
{
    $fromdate = date2sql($from);
    $todate = date2sql($to);
    $sql = "SELECT dm.tax_id, dm.name, dt.reference as trans_no, DATE_FORMAT(dt.`tran_date`, '%d-%b-%y') as date, (dt.ov_amount+dt.ov_gst+dt.ov_freight+dt.ov_freight_tax) as invoice_value ,
            st.sales_type, ttd.rate, dt.ov_amount as amount, dt.ov_freight as freight, state.state_code, state.name as state_name,dt.trans_no as act_no
            FROM `".TB_PREF."trans_tax_details` as ttd 
            LEFT JOIN `".TB_PREF."debtor_trans` as dt ON dt.trans_no = ttd.trans_no AND dt.type = ".ST_SALESINVOICE."
            LEFT JOIN `".TB_PREF."debtors_master` as dm ON  dt.debtor_no = dm.debtor_no 
            LEFT JOIN `".TB_PREF."sales_types` as st ON  dt.tpe = st.id 
            LEFT JOIN `".TB_PREF."customer_state` as state ON  dm.state_code = state.state_code 
            WHERE ttd.trans_type = ".ST_SALESINVOICE."
            AND ttd.`tran_date` BETWEEN  '$fromdate' AND '$todate' 
            GROUP BY dt.trans_no order by dt.reference";
    return db_query($sql,"No transactions were returned");
}

function print_tax_report()
{
    global $path_to_root, $systypes_array;

    $from = $_POST['PARAM_0'];
    $to = $_POST['PARAM_1'];
    $summaryOnly = $_POST['PARAM_2'];
    $comments = $_POST['PARAM_3'];
    $orientation = $_POST['PARAM_4'];
    $destination = $_POST['PARAM_5'];

    if ($destination)
        include_once($path_to_root . "/reporting/includes/excel_report.inc");
    else
        include_once($path_to_root . "/reporting/includes/pdf_report.inc");

    $orientation = 'L';
    $dec = user_price_dec();

    $rep = new FrontReport(_('GSTR-1'), "SalesSummaryReport", "A3", 9, $orientation);
    if ($summaryOnly == 1)
        $summary = _('Summary Only');
    else
        $summary = _('Detailed Report');

    $res = getTaxTypes();

    $taxes[0] = array('in' => 0, 'out' => 0, 'taxin' => 0, 'taxout' => 0);
    while ($tax = db_fetch($res))
        $taxes[$tax['id']] = array('in' => 0, 'out' => 0, 'taxin' => 0, 'taxout' => 0);

    $params = array(0 => $comments,
        1 => array('text' => _('Period'), 'from' => $from, 'to' => $to),
        2 => array('text' => _('Type'), 'from' => $summary, 'to' => ''));

    $headers = array(_('GSTIN/UIN of Recipient'), _('Receiver Name'), _('Invoice Number'), _('Invoice Date'), _('Invoice Value'),
        _('Freight Value'), _('Place of Supply'), _('Invoice Type'), _('Rate'), _('SGST'), _('CGST'), _('IGST'), _('Taxable Value'));

    $cols = array(0, 70, 230, 280, 320, 370, 420, 500, 540, 570, 620, 670, 725, 780);

    $headers3 = array(_('GSTIN/UIN of Recipient'), _('Receiver Name'), _('Invoice Number'), _('Invoice Date'), _('Invoice Value'),
        _('Freight Value'), _('Place of Supply'), _('Invoice Type'), _('Rate'), _('SGST'), _('CGST'), _('IGST'), _('Taxable Value'));

    $aligns = array('left', 'left', 'center', 'center', 'right', 'right', 'right', 'center', 'right', 'right', 'right', 'right', 'right');

    if ($orientation == 'L')
        recalculate_cols($cols);

    $rep->Font();
    $rep->Info($params, $cols, $headers, $aligns);
    if (!$summaryOnly) {
        $rep->NewPage();
    }
    $no_of_invoices = get_Total_no_of_records($from, $to);
    $no_of_recipients = get_Total_no_of_recipients($from, $to);
    $total_amount = get_total_transactions($from, $to);
    $each_trans = get_each_transactions($from, $to);

    $rep->Font('bold');
    $rep->TextCol(0, 1, _("No.of Invoices :"), -2);
    $rep->TextCol(1,2,	$no_of_invoices);
    $rep->Font();
    $rep->NewLine();

    $rep->Font('bold');
    $rep->TextCol(0, 1, _("No. of Recipients :"), -2);
    $rep->TextCol(1,2,	$no_of_recipients);
    $rep->Font();
    $rep->NewLine();

    $rep->Font('bold');
    $rep->TextCol(0, 1, _("Total Invoice Value :"), -2);
    $rep->TextCol(1,2,	price_format($total_amount['total']));
    $rep->Font();
    $rep->NewLine();

    $rep->Font('bold');
    $rep->TextCol(0, 1, _("Total Taxable Value :"), -2);
    $rep->TextCol(1,2,	price_format($total_amount['basic']));
    $rep->Font();
    $rep->NewLine(3);

    $x=0;
    $rep->Line($rep->row + 15);

    $count = count($rep->headers);
    for ($i = 0; $i < $count; $i++)
        $rep->TextCol($i, $i + 1, $headers3[$i]);

    $rep->Font();
    $rep->Line($rep->row-5);
    $rep->NewLine(2);
    $basic_value =0;
    $total_amount = 0;
    $frieght_value = 0;
    $sgst_total = 0;
    $cgst_total = 0;
    $igst_total = 0;

    while($trans = db_fetch($each_trans))
    {
        $taxes=get_trans_tax_details(ST_SALESINVOICE,$trans['act_no']);
        $sgst=0;
        $cgst=0;
        $igst=0;
        foreach ($taxes as $tax)
        {
            if (strpos(strtolower($tax['tax_type_name']), 'igst') !== false)
            {
                $igst += $tax['amount'];
                $igst_total += $tax['amount'];
                $rate=$tax['rate'];
            }
            else if(strpos(strtolower($tax['tax_type_name']), 'sgst') !== false)
            {
                $sgst += $tax['amount'];
                $sgst_total += $tax['amount'];
                $trans['rate']*=2;
            }
            else if(strpos(strtolower($tax['tax_type_name']), 'cgst') !== false)
            {
                $cgst += $tax['amount'];
                $cgst_total += $tax['amount'];
                $rate=$tax['rate'];
            }
        }
        $rep->fontSize += -2;
        $rep->TextCol(0, 1, $trans['tax_id'], -2);
        $rep->TextCol(1, 2, $trans['name'], -2);
        $rep->TextCol(2, 3, $trans['trans_no'], -2);
        $rep->TextCol(3, 4, $trans['date'], -2);
        $rep->TextCol(4, 5, price_format($trans['invoice_value']), -2);
        $rep->TextCol(5, 6, price_format($trans['freight']), -2);
        $rep->TextCol(6, 7, $trans['state_code']." - ".$trans['state_name']);
        $rep->TextCol(7, 8, $trans['sales_type'], -2);
        $rep->TextCol(8, 9, percent_format($trans['rate']), -2);
        $rep->TextCol(9, 10, price_format($sgst), -2);
        $rep->TextCol(10, 11, price_format($cgst), -2);
        $rep->TextCol(11, 12, price_format($igst), -2);
        $rep->TextCol(12, 13, price_format($trans['amount']), -2);
        $basic_value += $trans['amount'];
        $frieght_value += $trans['freight'];
        $total_amount += $trans['invoice_value'];
        $rep->fontSize -= -2;
        $rep->NewLine();
    }
    hook_tax_report_done();
    $rep->Line($rep->row);
    $rep->NewLine(1.2);
    $rep->Font('bold');
    $rep->TextCol(2, 4, "TOTAL :");
    $rep->AmountCol(9, 10, $sgst_total, $dec);
    $rep->AmountCol(10, 11, $cgst_total, $dec);
    $rep->AmountCol(11, 12, $igst_total, $dec);
    $rep->AmountCol(4, 5, $total_amount, $dec);
    $rep->AmountCol(5, 6, $frieght_value, $dec);
    $rep->AmountCol(12, 13, $basic_value, $dec);
    $rep->Font();
    $rep->NewLine(0.5);
    $rep->Line($rep->row);
    $rep->End();
}