ALTER TABLE `0_users` ADD `show_hints` TINYINT(1) DEFAULT '0' NOT NULL AFTER `show_codes` ;
