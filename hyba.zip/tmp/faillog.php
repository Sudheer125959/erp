<?php
/*
Login attempts info.
*/
$login_faillog = array (
  0 => 
  array (
    '103.77.37.150' => 0,
    'last' => '',
  ),
);
