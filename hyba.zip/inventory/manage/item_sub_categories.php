<?php
/**********************************************************************
Copyright (C) , LLC.
Released under the terms of the GNU General Public License, GPL,
as published by the Free Software Foundation, either version 3
of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the License here <http://www.gnu.org/licenses/gpl-3.0.html>.
 ***********************************************************************/
$page_security = 'SA_ITEMCATEGORY';
$path_to_root = "../..";
include($path_to_root . "/includes/session.inc");

$help_context = "Item Sub Categories";

$js = "";
if ($SysPrefs->use_popup_windows && $SysPrefs->use_popup_search)
    $js .= get_js_open_window(900, 600);

page(_($help_context), false, false, "", $js);

include_once($path_to_root . "/includes/ui.inc");
include_once($path_to_root . "/inventory/includes/inventory_db.inc");

simple_page_mode(true);
//----------------------------------------------------------------------------------

if ($Mode=='ADD_ITEM' || $Mode=='UPDATE_ITEM')
{

    //initialise no input errors assumed initially before we test
    $input_error = 0;
    if (strlen($_POST['sub_cat_code']) == 0)
    {
        $input_error = 1;
        display_error(_("The item sub category code cannot be empty."));
        set_focus('sub_cat_code');
    }
    if (key_in_foreign_table($_POST['sub_cat_code'],'stock_sub_category','sub_cat_code')&&$Mode!='UPDATE_ITEM')
    {
        $input_error = 1;
        display_error(_("This item sub category code has already taken."));
        set_focus('sub_cat_code');
    }
    if (strlen($_POST['description']) == 0)
    {
        $input_error = 1;
        display_error(_("The item sub category description cannot be empty."));
        set_focus('description');
    }

    if ($input_error !=1)
    {
        if ($selected_id != -1)
        {
            update_item_sub_category($selected_id, $_POST['description']);
            display_notification(_('Selected item sub category has been updated'));
        }
        else
        {
            add_item_sub_category($_POST['sub_cat_code'],$_POST['description']);
            display_notification(_('New item sub category has been added'));
        }
        $Mode = 'RESET';
    }
}

//----------------------------------------------------------------------------------

if ($Mode == 'Delete')
{

    // PREVENT DELETES IF DEPENDENT RECORDS IN 'stock_master'
    if (key_in_foreign_table($selected_id, 'cat_sub_cat', 'sub_cat_code'))
    {
        display_error(_("Cannot delete this item sub category because items categories have been created using this item sub category."));
    }
    else
    {
        delete_item_sub_category($selected_id);
        display_notification(_('Selected item sub category has been deleted'));
    }
    $Mode = 'RESET';
}

if ($Mode == 'RESET')
{
    $selected_id = -1;
    $sav = get_post('show_inactive');
    unset($_POST);
    $_POST['show_inactive'] = $sav;
}

//----------------------------------------------------------------------------------

$result = get_item_sub_categories(check_value('show_inactive'));

start_form();
start_table(TABLESTYLE, "width='40%'");
$th = array(_("Code"),_("Description"), "", "");

inactive_control_column($th);

table_header($th);
$k = 0; //row colour counter

while ($myrow = db_fetch($result))
{

    alt_table_row_color($k);
    label_cell($myrow["sub_cat_code"]);
    label_cell($myrow["description"]);
    inactive_control_cell($myrow["sub_cat_code"], $myrow["inactive"], 'stock_sub_category', 'sub_cat_code');
    edit_button_cell("Edit".$myrow["sub_cat_code"], _("Edit"));
    delete_button_cell("Delete".$myrow["sub_cat_code"], _("Delete"));
    end_row();
}

inactive_control_row($th);
end_table();
echo '<br>';
//----------------------------------------------------------------------------------

div_start('details');
start_table(TABLESTYLE2);

if ($selected_id != -1)
{
    if ($Mode == 'Edit') {
        //editing an existing item category
        $myrow = get_item_sub_category($selected_id);

        $_POST['sub_cat_code'] = $myrow["sub_cat_code"];
        $_POST['description']  = $myrow["description"];
    }
    label_row(_("Sub Category Name:"),$_POST['sub_cat_code']);
    hidden('selected_id', $selected_id);
    hidden('sub_cat_code',$_POST['sub_cat_code']);
}else
    text_row(_("Sub Category Code:"), 'sub_cat_code', null, 30, 30);
text_row(_("Sub Category Name:"), 'description', null, 30, 30);

end_table(1);
div_end();
submit_add_or_update_center($selected_id == -1, '', 'both');
end_form();
end_page();