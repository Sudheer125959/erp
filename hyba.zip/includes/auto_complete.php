<?php
/**
 * Created by PhpStorm.
 * User: MB
 * Date: 28-Dec-18
 * Time: 9:55 PM
 */


$path_to_root = "..";

include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/includes/ui/ui_globals.inc");


$query = $_GET['q'];
$type = $_GET['type'];

$options = array();
switch (strtolower($type)) {
    case "stock":
        $items = get_items_search_autocomplete($query, "all");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "stock_manufactured":
        $items = get_items_search_autocomplete($query, "manufactured");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "stock_purchased":
        $items = get_items_search_autocomplete($query, "purchasable");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "stock_sales":
        $items = get_items_search_autocomplete($query, "sales");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "stock_costable":
        $items = get_items_search_autocomplete($query, "costable");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "component":
        $_GET['parent'] = $opts['parent'];
        $items = get_items_search_autocomplete($query, "component");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "kits":
        $items = get_items_search_autocomplete($query, "kits");
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "customer":
        $items = get_customers_search_autocomplete($query);
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "branch":
        $items = get_branches_search_autocomplete(get_global_customer(), $query);
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "supplier":
        $items = get_suppliers_search_autocomplete($query);
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
    case "account":
    case "account2";
        $skip = strtolower($type) == "account" ? false : true;
        $items = get_chart_accounts_search_autocomplete($query, $skip);
        while ($r = db_fetch($items)) {
            $options[] = $r;
        }
        break;
}

echo json_encode($options);

function get_items_search_autocomplete($description, $type)
{
    global $SysPrefs;

    $sql = "SELECT COUNT(i.item_code) AS kit, i.item_code, i.description, c.description category
		FROM " . TB_PREF . "stock_master s, " . TB_PREF . "item_codes i
			LEFT JOIN " . TB_PREF . "stock_category c ON i.category_id=c.category_id
		WHERE i.stock_id=s.stock_id
			AND !i.inactive AND !s.inactive
			AND ( i.item_code LIKE " . db_escape("%" . $description . "%") . " OR 
				i.description LIKE " . db_escape("%" . $description . "%") . " OR 
				c.description LIKE " . db_escape("%" . $description . "%") . ") ";

    switch ($type) {
        case "sales":
            $sql .= " AND !s.no_sale AND mb_flag <> 'F'";
            break;
        case "manufactured":
            $sql .= " AND mb_flag = 'M'";
            break;
        case "purchasable":
            $sql .= " AND NOT no_purchase AND mb_flag <> 'F' AND i.item_code=i.stock_id";
            break;
        case "costable":
            $sql .= " AND mb_flag <> 'D' AND mb_flag <> 'F' AND  i.item_code=i.stock_id";
            break;
        case "component":
            $parent = $_GET['parent'];
            $sql .= " AND  i.item_code=i.stock_id AND i.stock_id <> '$parent' AND mb_flag <> 'F' ";
            break;
        case "kits":
            $sql .= " AND !i.is_foreign AND i.item_code!=i.stock_id AND mb_flag <> 'F'";
            break;
        case "all":
            $sql .= " AND mb_flag <> 'F' AND i.item_code=i.stock_id";
            break;
    }

    if (isset($SysPrefs->max_rows_in_search))
        $limit = $SysPrefs->max_rows_in_search;
    else
        $limit = 10;

    $sql .= " GROUP BY i.category_id,i.item_code ORDER BY i.category_id,i.description LIMIT 0," . (int)($limit);

    return db_query($sql, "Failed in retreiving item list.");
}

function get_customers_search_autocomplete($customer)
{
    global $SysPrefs;

    if (isset($SysPrefs->max_rows_in_search))
        $limit = $SysPrefs->max_rows_in_search;
    else
        $limit = 10;

    $sql = "SELECT debtor_no as opt1, name as opt2 FROM ".TB_PREF."debtors_master 
	  WHERE (  name LIKE " . db_escape("%" . $customer. "%") . " OR 
    		 debtor_ref LIKE " . db_escape("%" . $customer. "%") . " OR 
	        address LIKE " . db_escape("%" . $customer. "%") . " OR 
    	     tax_id LIKE " . db_escape("%" . $customer. "%").")
	  ORDER BY name LIMIT 0,".(int)($limit);

    return db_query($sql, "Failed in retreiving customer list.");
}

function  get_branches_search_autocomplete($customer, $branch)
{
    global $SysPrefs;

    if (isset($SysPrefs->max_rows_in_search))
        $limit = $SysPrefs->max_rows_in_search;
    else
        $limit = 10;

    $sql = "SELECT 
		    b.branch_code as opt1,
	    	b.br_name as opt2
		FROM ".TB_PREF."cust_branch b
		WHERE b.debtor_no = ".db_escape($customer)."
			AND b.br_name LIKE " . db_escape("%" . $branch. "%") . "
		ORDER BY b.br_name LIMIT 0,".(int)($limit);

    return db_query($sql, "Failed in retreiving branches list.");
}

function get_suppliers_search_autocomplete($supplier)
{
    global $SysPrefs;

    if (isset($SysPrefs->max_rows_in_search))
        $limit = $SysPrefs->max_rows_in_search;
    else
        $limit = 10;

    $sql = "SELECT supplier_id as opt1, supp_name as opt2
		FROM ".TB_PREF."suppliers
		WHERE (supp_name LIKE " . db_escape("%" . $supplier. "%") . " OR 
			supp_ref LIKE " . db_escape("%" . $supplier. "%") . " OR 
			address LIKE " . db_escape("%" . $supplier. "%") . " OR 
			gst_no LIKE " . db_escape("%" . $supplier. "%") . ")
		ORDER BY supp_name LIMIT 0,".(int)($limit);

    return db_query($sql, "Failed in retreiving supplier list.");
}

function get_chart_accounts_search_autocomplete($like, $skip=false)
{
    global $SysPrefs;

    if (isset($SysPrefs->max_rows_in_search))
        $limit = $SysPrefs->max_rows_in_search;
    else
        $limit = 10;

    if ($skip)
        $sql = "SELECT chart.account_code as opt1, chart.account_name as opt2
			FROM (".TB_PREF."chart_master chart,".TB_PREF."chart_types type) "
            ."LEFT JOIN ".TB_PREF."bank_accounts acc "
            ."ON chart.account_code=acc.account_code
				WHERE acc.account_code  IS NULL
			AND chart.account_type=type.id ";
    else
        $sql = "SELECT chart.account_code as opt1, chart.account_name as opt2
			FROM ".TB_PREF."chart_master chart,".TB_PREF."chart_types type WHERE chart.account_type=type.id ";
    $sql .= "AND (
          	chart.account_name LIKE " . db_escape("%" . $like. "%") . " OR
          	chart.account_code LIKE " . db_escape("%" . $like. "%") . "
        	) 
    		ORDER BY chart.account_code LIMIT 0,".(int)($limit); // We only display 10 items.
    return db_query($sql, "Failed in retreiving GL account list.");
}