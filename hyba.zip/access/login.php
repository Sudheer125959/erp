<?php

	if (!isset($path_to_root) || isset($_GET['path_to_root']) || isset($_POST['path_to_root']))
		die(_("Restricted access"));
	include_once($path_to_root . "/includes/ui.inc");
	include_once($path_to_root . "/includes/page/header.inc");

	$js = "<script language='JavaScript' type='text/javascript'>
function defaultCompany()
{
	document.forms[0].company_login_name.options[".$_SESSION["wa_current_user"]->company."].selected = true;
}
</script>";
	add_js_file('login.js');
	// Display demo user name and password within login form if "$allow_demo_mode" is true
	if ($allow_demo_mode == true)
	{
	    $demo_text = _("Login as user: demouser and password: password");
	}
	else
	{
		//$demo_text = _("Please login here");
    if (@$allow_password_reset) {
      $demo_text .= " <a href='$path_to_root/index.php?reset=1'>"._("request new password")."</a>";
    }
	}

	if (check_faillog())
	{
		$blocked_msg = '<span class=redfg>'._('Too many failed login attempts.<br>Please wait a while or try later.').'</span>';

	    $js .= "<script>setTimeout(function() {
	    	document.getElementsByName('SubmitUser')[0].disabled=0;
	    	document.getElementById('log_msg').innerHTML='$demo_text'}, 1000*$login_delay);</script>";
	    $demo_text = $blocked_msg;
	}
	if (!isset($def_coy))
		$def_coy = 0;
	$def_theme = "default";

	$login_timeout = $_SESSION["wa_current_user"]->last_act;

	$title = $login_timeout ? _('Authorization timeout') : $app_title." Your Company Name Goes Here ";
	$encoding = isset($_SESSION['language']->encoding) ? $_SESSION['language']->encoding : "iso-8859-1";
	$rtl = isset($_SESSION['language']->dir) ? $_SESSION['language']->dir : "ltr";
	$onload = !$login_timeout ? "onload='defaultCompany()'" : "";

	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"https://www.w3.org/TR/html4/loose.dtd\">\n";
	echo "<html dir='$rtl' >\n";
	echo "<head profile=\"https://www.w3.org/2005/10/profile\"><title>$title</title>\n";
   	echo "<meta http-equiv='Content-type' content='text/html; charset=$encoding' />\n";
    echo "<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css' rel='stylesheet' > \n";
    echo "<link href='$path_to_root/themes/default/images/favicon.png' rel='shortcut icon'> \n";
	send_scripts();
	if (!$login_timeout)
	{
		echo $js;
	}
	echo'<style>.wrapper,body,html{height:100%;background-size:cover;width:100%}.myButton,.smGlobalBtn{display:inline-block;cursor:pointer}#social,.copyright,.message,.smGlobalBtn,.wrapper{text-align:center}*,:after,:before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-weight:1000;margin:0;outline:0;font-family:"Open Sans";padding:0}body{background:#fffff;background:-moz-linear-gradient(top,#fffff 0,#fffff 100%);background:-webkit-linear-gradient(top,#fffff 0,#fffff 100%);background:linear-gradient(to bottom,#fffff 0,#fffff 100%);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=\'#fffff\', endColorstr=\'#fffff\', GradientType=0)}.wrapper .brand{padding-top:5%}
  .login{padding-top:2%;width:300px;margin:0 auto}input,
   select{
   color:#000;font-size:15px;outline:0;padding:10px}
   .login form,input,select{width:100%}
    select{background:url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'50px\' height=\'50px\'><polyline points=\'46.139,15.518 25.166,36.49 4.193,15.519\'/></svg>") right 10px top 11px no-repeat #fff;background-size:16px 16px;border-radius:0px;margin-bottom:40px;-webkit-border-radius:0px;-webkit-appearance:none;max-width:100%;-webkit-transition:.3s ease all;-moz-transition:.3s ease all;-ms-transition:.3s ease all;-o-transition:.3s ease all;transition:.3s ease all}.memblogin select:focus{border-color:#01314F}input{background:#fff;border:1px solid rgba(0,0,0,.3);border-radius:0px;margin-bottom:20px}button{border:none}
    .myButton{cursor: pointer;
    border-radius: 0em;
    color: #fff;
    background: steelblue;
    border: 0;
    width:fit-content;
    align-text: center;
    padding-left: 40px;
    padding-right: 40px;
    padding-bottom: 10px;
    padding-top: 10px;
    font-weight: bolder;
    font-family: \'Ubuntu\', sans-serif;
    margin-left: 0%;
    font-size: 20px;
    }
    .facebookBtn:before,
    .googleplusBtn:before,
    .linkedinBtn:before,.pinterestBtn:before,
    .rssBtn:before,
    .tumblrBtn:before,
    .twitterBtn:before{font-family:FontAwesome}
    .myButton:hover{background:-webkit-gradient(linear,left top,left bottom,color-stop(.05,#5cbf2a),color-stop(1,#44c767));background:-moz-linear-gradient(top,#5cbf2a 5%,#44c767 100%);background:-webkit-linear-gradient(top,#5cbf2a 5%,#44c767 100%);background:-o-linear-gradient(top,#5cbf2a 5%,#44c767 100%);background:-ms-linear-gradient(top,#5cbf2a 5%,#44c767 100%);background:linear-gradient(to bottom,#5cbf2a 5%,#44c767 100%);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=\'#5cbf2a\', endColorstr=\'#44c767\', GradientType=0);background-color:#5cbf2a}.myButton:active{position:relative;top:1px}hr{border:0;height:1px;background-image:linear-gradient(to right,rgba(0,0,0,0),rgba(174,174,174,.75),rgba(0,0,0,0))}#social{margin:20px 10px}.smGlobalBtn{position:relative;width:40px;height:40px;border:2px solid #ddd;padding:0;text-decoration:none;color:#fff;font-size:22px;font-weight:400;line-height:1.6em;border-radius:27px;-moz-border-radius:27px;-webkit-border-radius:27px}.facebookBtn{background:#4060A5}.facebookBtn:before{content:"\f09a"}.facebookBtn:hover{color:#4060A5;background:#fff;border-color:#4060A5}.twitterBtn{background:#00ABE3}.twitterBtn:before{content:"\f099"}.twitterBtn:hover{color:#00ABE3;background:#fff;border-color:#00ABE3}.googleplusBtn{background:#e64522}.googleplusBtn:before{content:"\f0d5"}.googleplusBtn:hover{color:#e64522;background:#fff;border-color:#e64522}.linkedinBtn{background:#0094BC}.linkedinBtn:before{content:"\f0e1"}.linkedinBtn:hover{color:#0094BC;background:#fff;border-color:#0094BC}.pinterestBtn{background:#cb2027}.pinterestBtn:before{content:"\f0d2"}.pinterestBtn:hover{color:#cb2027;background:#fff;border-color:#cb2027}.tumblrBtn{background:#3a5876}.tumblrBtn:before{content:"\f173"}.tumblrBtn:hover{color:#3a5876;background:#fff;border-color:#3a5876}.rssBtn{background:#e88845}.rssBtn:before{content:"\f09e"}.rssBtn:hover{color:#e88845;background:#fff;border-color:#e88845}.footer{position:absolute;bottom:0;width:100%;height:40px;clear:none}.message{font-size:1.5em;color:#efc1c2}.copyright{vertical-align:center;padding:3px;font-size:1.1em;color:#fdffff;position:relative}.pwdfrgt{color:#fdffff;position:absolute;top:5px;right:10px}.instagramBtn{
    background-color: #F3EBF6;
}

.instagramBtn:before{
      font-family: "FontAwesome";
      content:  "\f16d"; /* add instagram icon */
      
}

.instagramBtn:hover{
      color: #517FA4;
      background: #fff;
      border-color: #517FA4;
}
.youtubeBtn{
    background: #F33;
}

.youtubeBtn:before{
      font-family: "FontAwesome";
      content: "\f167"; /* add youtube icon */
}

.youtubeBtn:hover{
      color: #F33;
      background: #fff;
      border-color: #F33;
}

</style>';

echo "</head>\n";

	echo "<body background='$path_to_root/themes/bluecolor/images/1.jpg' id='loginscreen' $onload>\n";

echo "<div class='wrapper'>\n";
echo "    <h1 class='brand'><a target='_blank' href='".$SysPrefs->power_url."'>
    <img src='$path_to_root/themes/mix/images/logo.png' alt='Your Company Name' onload='fixPNG(this)' ></a></h1>\n";
if ($login_timeout){
    echo " <p class='message'>\n";
    echo " Authorization Timeout\n";
    echo " </p>\n";
}

echo " <form method='post' action=".$_SESSION['timeout']['uri']." name='loginform' class='login-container'>\n";
echo " <div class='login'>\n";
echo "<input type='hidden' id=ui_mode name='ui_mode' value='".$_SESSION["wa_current_user"]->ui_mode."' />\n";+
$value = $login_timeout ? $_SESSION['wa_current_user']->loginname : ($allow_demo_mode ? "demouser":"");
echo "  <input type='text' placeholder='Username' name='user_name_entry_field' value=\"$value\" required='required'/>\n";
$password = $allow_demo_mode ? "password":"";
echo "<p><input type='password' placeholder='Password' name='password' value=\"$password\" required='required'></p>";
if ($login_timeout) {
    hidden('company_login_name', user_company());
} else {
    $coy =  user_company();
    if (!isset($coy))
        $coy = $def_coy;
    if (!@$SysPrefs->text_company_selection) {
        echo '<p><select name=\'company_login_name\'>';
        //echo '<option>Select a Company</option>';
        for ($i = 0; $i < count($db_connections); $i++)
            echo "<option value=$i ".($i==$coy ? 'selected':'') .">" . $db_connections[$i]["name"] . "</option>";
        echo '</select></p>';
    } else {
//			$coy = $def_coy;
        echo "<p><input type='text' placeholder='Company Name' name='company_login_nickname' value=''></p>";
    }
}

echo "<p ><input class='myButton' type='submit' value='Login' name='SubmitUser'".($login_timeout ? '':" onclick='set_fullmode();'").(isset($blocked_msg) ? " disabled" : '')."></p>";
$Ajax->addUpdate('log_msg', 'log_msg', $demo_text);
foreach($_SESSION['timeout']['post'] as $p => $val) {
    // add all request variables to be resend together with login data
    if (!in_array($p, array('ui_mode', 'user_name_entry_field',
        'password', 'SubmitUser', 'company_login_name')))
        echo "<input type='hidden' name='$p' value='$val'>";
}

echo "    </div>\n";
echo "    <br><br>\n";
echo "    <hr>\n";
echo "    <div class='footer'>";
echo "        <div class='copyright'>";
echo "            <span  id='log_msg' class='pwdfrgt'>$demo_text</span>";
//echo "     <a href='http://www.suzalkem.com' target='_blank'><span style='color:#fff'>www.suzalkem.com</span>\n</a>";
echo "        </div>\n";
echo "    </div>\n";
echo "        </form>\n";
echo "</div>\n";

echo "<script language='JavaScript' type='text/javascript'>
    //<![CDATA[
            <!--
            document.forms[0].user_name_entry_field.select();
            document.forms[0].user_name_entry_field.focus();
            //-->
    //]]>
    </script>";
	echo "</body></html>\n";
?>